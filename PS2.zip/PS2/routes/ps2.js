var express = require('express');
var router = express.Router();

/* GET home page. */

/* b */
router.get('/', function(req, res, next) {
  res.render('index', { input_string: 'Hey now',
    display: true});
})

/* c */
    .post('/', function(req, res, next) {
      res.render('index',
          {original_string: req.body.original_string,
              string_length: req.body.original_string.length,
              display: true})
    })

/* d */
router.get('/names/:name', function(req, res, next) {
  res.render('index',
      {name: req.params.name,
        name_length: req.params.name.length,
        display: true})
})

module.exports = router;
